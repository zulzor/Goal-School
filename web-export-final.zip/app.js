// Простая веб-версия приложения футбольной школы "Арсенал"
(function () {
  // Цвета клуба "Арсенал"
  const COLORS = {
    primary: '#EF0107', // Красный Arsenal
    secondary: '#023474', // Синий Arsenal
    background: '#f5f5f5',
    surface: '#ffffff',
    text: '#212121',
    border: '#e0e0e0',
    accent: '#FFD700', // Золотой для акцентов
  };

  // Создаем основной контейнер
  const appContainer = document.createElement('div');
  appContainer.id = 'app';
  appContainer.style.fontFamily =
    '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif';
  appContainer.style.backgroundColor = COLORS.background;
  appContainer.style.minHeight = '100vh';
  appContainer.style.display = 'flex';
  appContainer.style.flexDirection = 'column';
  document.body.appendChild(appContainer);

  // Создаем заголовок приложения
  const header = document.createElement('header');
  header.style.backgroundColor = COLORS.primary;
  header.style.color = COLORS.surface;
  header.style.padding = '1rem';
  header.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
  header.style.position = 'sticky';
  header.style.top = '0';
  header.style.zIndex = '100';

  const headerContent = document.createElement('div');
  headerContent.style.display = 'flex';
  headerContent.style.justifyContent = 'space-between';
  headerContent.style.alignItems = 'center';
  headerContent.style.maxWidth = '1200px';
  headerContent.style.margin = '0 auto';

  const title = document.createElement('h1');
  title.textContent = 'Футбольная школа "Арсенал"';
  title.style.margin = '0';
  title.style.fontSize = '1.5rem';

  const nav = document.createElement('nav');
  nav.innerHTML = `
    <a href="#" style="color: ${COLORS.surface}; text-decoration: none; margin-left: 1rem;">Главная</a>
    <a href="#" style="color: ${COLORS.surface}; text-decoration: none; margin-left: 1rem;">Расписание</a>
    <a href="#" style="color: ${COLORS.surface}; text-decoration: none; margin-left: 1rem;">Новости</a>
    <a href="#" style="color: ${COLORS.surface}; text-decoration: none; margin-left: 1rem;">Профиль</a>
  `;

  headerContent.appendChild(title);
  headerContent.appendChild(nav);
  header.appendChild(headerContent);
  appContainer.appendChild(header);

  // Создаем основной контент
  const main = document.createElement('main');
  main.style.flex = '1';
  main.style.padding = '2rem';
  main.style.maxWidth = '1200px';
  main.style.margin = '0 auto';
  main.style.width = '100%';

  // Создаем секцию приветствия
  const welcomeSection = document.createElement('section');
  welcomeSection.style.backgroundColor = COLORS.surface;
  welcomeSection.style.borderRadius = '8px';
  welcomeSection.style.padding = '2rem';
  welcomeSection.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
  welcomeSection.style.marginBottom = '2rem';
  welcomeSection.style.textAlign = 'center';

  const welcomeTitle = document.createElement('h2');
  welcomeTitle.textContent = 'Добро пожаловать в футбольную школу "Арсенал"!';
  welcomeTitle.style.color = COLORS.primary;
  welcomeTitle.style.marginTop = '0';

  const welcomeText = document.createElement('p');
  welcomeText.textContent =
    'Здесь вы можете отслеживать расписание тренировок, просматривать новости школы и следить за своим прогрессом.';
  welcomeText.style.fontSize = '1.1rem';
  welcomeText.style.color = COLORS.text;
  welcomeText.style.lineHeight = '1.6';

  welcomeSection.appendChild(welcomeTitle);
  welcomeSection.appendChild(welcomeText);
  main.appendChild(welcomeSection);

  // Создаем секцию функций
  const featuresSection = document.createElement('section');
  featuresSection.style.marginBottom = '2rem';

  const featuresTitle = document.createElement('h2');
  featuresTitle.textContent = 'Функции приложения';
  featuresTitle.style.color = COLORS.text;
  featuresTitle.style.marginBottom = '1rem';
  featuresTitle.style.textAlign = 'center';

  const featuresGrid = document.createElement('div');
  featuresGrid.style.display = 'grid';
  featuresGrid.style.gridTemplateColumns = 'repeat(auto-fit, minmax(250px, 1fr))';
  featuresGrid.style.gap = '1.5rem';

  const features = [
    {
      title: 'Расписание тренировок',
      description: 'Просматривайте расписание тренировок и записывайтесь на занятия',
      icon: '📅',
    },
    {
      title: 'Новости школы',
      description: 'Будьте в курсе последних новостей и событий футбольной школы',
      icon: '📰',
    },
    {
      title: 'Прогресс учеников',
      description: 'Отслеживайте свой прогресс и достижения в различных дисциплинах',
      icon: '📈',
    },
    {
      title: 'Рекомендации по питанию',
      description: 'Получайте персонализированные рекомендации по питанию',
      icon: '🍎',
    },
  ];

  features.forEach(feature => {
    const featureCard = document.createElement('div');
    featureCard.style.backgroundColor = COLORS.surface;
    featureCard.style.borderRadius = '8px';
    featureCard.style.padding = '1.5rem';
    featureCard.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
    featureCard.style.transition = 'transform 0.2s ease';

    featureCard.onmouseover = () => {
      featureCard.style.transform = 'translateY(-5px)';
    };

    featureCard.onmouseout = () => {
      featureCard.style.transform = 'translateY(0)';
    };

    const featureIcon = document.createElement('div');
    featureIcon.textContent = feature.icon;
    featureIcon.style.fontSize = '2rem';
    featureIcon.style.marginBottom = '1rem';

    const featureTitle = document.createElement('h3');
    featureTitle.textContent = feature.title;
    featureTitle.style.color = COLORS.primary;
    featureTitle.style.marginTop = '0';
    featureTitle.style.marginBottom = '0.5rem';

    const featureDescription = document.createElement('p');
    featureDescription.textContent = feature.description;
    featureDescription.style.color = COLORS.text;
    featureDescription.style.margin = '0';
    featureDescription.style.fontSize = '0.9rem';

    featureCard.appendChild(featureIcon);
    featureCard.appendChild(featureTitle);
    featureCard.appendChild(featureDescription);
    featuresGrid.appendChild(featureCard);
  });

  featuresSection.appendChild(featuresTitle);
  featuresSection.appendChild(featuresGrid);
  main.appendChild(featuresSection);

  // Создаем секцию последних новостей
  const newsSection = document.createElement('section');

  const newsTitle = document.createElement('h2');
  newsTitle.textContent = 'Последние новости';
  newsTitle.style.color = COLORS.text;
  newsTitle.style.marginBottom = '1rem';
  newsTitle.style.textAlign = 'center';

  const newsList = document.createElement('div');
  newsList.style.display = 'grid';
  newsList.style.gridTemplateColumns = 'repeat(auto-fit, minmax(300px, 1fr))';
  newsList.style.gap = '1.5rem';

  const newsItems = [
    {
      title: 'Новая тренировочная программа',
      date: '10 сентября 2025',
      excerpt: 'Мы внедрили новую программу тренировок для всех возрастных групп...',
    },
    {
      title: 'Победа на турнире',
      date: '8 сентября 2025',
      excerpt: 'Наши юные футболисты одержали победу в региональном турнире...',
    },
    {
      title: 'Открытие нового филиала',
      date: '5 сентября 2025',
      excerpt: 'Рады сообщить об открытии нового филиала школы в центре города...',
    },
  ];

  newsItems.forEach(news => {
    const newsCard = document.createElement('div');
    newsCard.style.backgroundColor = COLORS.surface;
    newsCard.style.borderRadius = '8px';
    newsCard.style.padding = '1.5rem';
    newsCard.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';

    const newsDate = document.createElement('div');
    newsDate.textContent = news.date;
    newsDate.style.fontSize = '0.8rem';
    newsDate.style.color = COLORS.secondary;
    newsDate.style.marginBottom = '0.5rem';

    const newsTitle = document.createElement('h3');
    newsTitle.textContent = news.title;
    newsTitle.style.color = COLORS.primary;
    newsTitle.style.marginTop = '0';
    newsTitle.style.marginBottom = '0.5rem';

    const newsExcerpt = document.createElement('p');
    newsExcerpt.textContent = news.excerpt;
    newsExcerpt.style.color = COLORS.text;
    newsExcerpt.style.margin = '0';
    newsExcerpt.style.fontSize = '0.9rem';

    newsCard.appendChild(newsDate);
    newsCard.appendChild(newsTitle);
    newsCard.appendChild(newsExcerpt);
    newsList.appendChild(newsCard);
  });

  newsSection.appendChild(newsTitle);
  newsSection.appendChild(newsList);
  main.appendChild(newsSection);

  appContainer.appendChild(main);

  // Создаем футер
  const footer = document.createElement('footer');
  footer.style.backgroundColor = COLORS.secondary;
  footer.style.color = COLORS.surface;
  footer.style.padding = '2rem';
  footer.style.textAlign = 'center';

  const footerContent = document.createElement('div');
  footerContent.style.maxWidth = '1200px';
  footerContent.style.margin = '0 auto';

  const footerText = document.createElement('p');
  footerText.textContent = '© 2025 Футбольная школа "Арсенал". Все права защищены.';
  footerText.style.margin = '0';

  const footerLinks = document.createElement('div');
  footerLinks.style.marginTop = '1rem';
  footerLinks.innerHTML = `
    <a href="#" style="color: ${COLORS.surface}; text-decoration: none; margin: 0 0.5rem;">Контакты</a>
    <a href="#" style="color: ${COLORS.surface}; text-decoration: none; margin: 0 0.5rem;">Политика конфиденциальности</a>
    <a href="#" style="color: ${COLORS.surface}; text-decoration: none; margin: 0 0.5rem;">Условия использования</a>
  `;

  footerContent.appendChild(footerText);
  footerContent.appendChild(footerLinks);
  footer.appendChild(footerContent);
  appContainer.appendChild(footer);

  console.log('Приложение футбольной школы "Арсенал" загружено');
})();
